//
//  const.swift
//  ExamAI V2
//
//  Created by Apple Esprit on 18/11/2024.
//

import Foundation
struct const{
    static let BACKEND_URL = "http://192.168.39.121:3000"
}
