//
//  ExamAI_V2App.swift
//  ExamAI V2
//
//  Created by Mac Mini 11 on 8/11/2024.
//

import SwiftUI

@main
struct ExamAI_V2App: App {
    init() {
            // Set up a non-transparent tab bar
            let tabBarAppearance = UITabBarAppearance()
            tabBarAppearance.configureWithOpaqueBackground() // Makes the tab bar opaque
            tabBarAppearance.backgroundColor = UIColor.white // Set desired background color

            UITabBar.appearance().standardAppearance = tabBarAppearance
            UITabBar.appearance().scrollEdgeAppearance = tabBarAppearance
        }
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            GetStartedView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
