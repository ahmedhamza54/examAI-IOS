import PDFKit
import UIKit

class PDFGenerator {
    private static func createPDF(from text: String) -> URL? {
        let pdfDocument = PDFDocument()

        // Create a single page with rendered text
        let pageBounds = CGRect(x: 0, y: 0, width: 612, height: 792) // A4 size
        let renderer = UIGraphicsImageRenderer(bounds: pageBounds)
        let pdfImage = renderer.image { context in
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.alignment = .left
            
            let attributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 14),
                .foregroundColor: UIColor.black,
                .paragraphStyle: paragraphStyle
            ]
            
            text.draw(in: pageBounds.insetBy(dx: 20, dy: 20), withAttributes: attributes)
        }

        if let page = PDFPage(image: pdfImage) {
            pdfDocument.insert(page, at: 0)
        }

        // Save PDF to Documents directory
        let fileManager = FileManager.default
        let fileURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!.appendingPathComponent("exam_preview.pdf")

        if pdfDocument.write(to: fileURL) {
            print("PDF successfully written to: \(fileURL)")
            return fileURL
        } else {
            print("Failed to write PDF to: \(fileURL)")
            return nil
        }
    }
    func createPDF(from text: String) -> URL? {
        let pdfRenderer = UIGraphicsPDFRenderer(bounds: CGRect(x: 0, y: 0, width: 595.2, height: 841.8)) // Standard A4 size
        let pdfData = pdfRenderer.pdfData { (context) in
            context.beginPage()
            let attributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 12),
                .foregroundColor: UIColor.black
            ]
            let textRect = CGRect(x: 20, y: 20, width: 555.2, height: 801.8)
            text.draw(in: textRect, withAttributes: attributes)
        }
        
        // Save the PDF to the Documents directory
        let fileManager = FileManager.default
        let documentsDirectory = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!
        let pdfURL = documentsDirectory.appendingPathComponent("exam_\(UUID().uuidString).pdf")
        
        do {
            try pdfData.write(to: pdfURL)
        } catch {
            print("Error writing PDF file: \(error)")
        }
        
        return pdfURL
    }

}
